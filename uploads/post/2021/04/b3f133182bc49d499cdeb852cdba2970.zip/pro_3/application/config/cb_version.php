<?php
defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * CiBoard 주 : 현재 설치되어 있는 씨아이보드 버전입니다.
 */


define('CB_PACKAGE', 'pro');
define('CB_VERSION', '3.0.4');

$config['cb_version'] = array();
