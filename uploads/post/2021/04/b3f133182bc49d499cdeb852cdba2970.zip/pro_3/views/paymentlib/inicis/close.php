<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<script language="javascript" type="text/javascript" src="https://stgstdpay.inicis.com/stdjs/INIStdPay_close.js" charset="UTF-8"></script>