<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<script language="javascript" type="text/javascript" src="https://stdpay.inicis.com/stdjs/INIStdPay_popup.js" charset="UTF-8"></script>